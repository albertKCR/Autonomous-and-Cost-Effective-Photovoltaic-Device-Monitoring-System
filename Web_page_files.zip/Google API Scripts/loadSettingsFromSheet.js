function doGet(e){
  var ss = SpreadsheetApp.openById('1ELHCl-1dL5LFJFQ-sP02MA2dvbyNQNiFwArYep-9QsU');
  var sheet = ss.getSheetByName('Form Responses 1');
  var sheet1 = ss.getSheetByName('Config');

  var row = sheet.getLastRow();
  var dataArr = new Array();
  dataArr[0] = sheet.getSheetValues(row, 2, 1, 1)[0][0];
  dataArr[1] = sheet.getSheetValues(row, 3, 1, 1)[0][0];
  dataArr[2] = sheet.getSheetValues(row, 4, 1, 1)[0][0];
  dataArr[3] = sheet.getSheetValues(row, 5, 1, 1)[0][0];
  dataArr[5] = sheet.getSheetValues(row, 6, 1, 1)[0][0];
  dataArr[4] = sheet.getSheetValues(row, 7, 1, 1)[0][0];
  sheet1.deleteRow(2);
  sheet1.appendRow(dataArr);
  sheet1.getRange("A2").setNumberFormat("@");
  
  return ContentService.createTextOutput(sheet1.getRange("A2:F2").getValues());

}