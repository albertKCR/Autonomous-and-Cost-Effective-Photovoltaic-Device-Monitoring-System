var SS = SpreadsheetApp.openById('1ELHCl-1dL5LFJFQ-sP02MA2dvbyNQNiFwArYep-9QsU');
var str = "";

function test() {
  return valOrg();
}

function doGet(e) {
  return valOrg();
}

function valOrg() {
  var sheet1 = SS.getSheetByName("Sheet1");
  var range = sheet1.getRange("C2:D2");
  if (!range.isBlank()) {
    var sheet = SS.getSheetByName("tempdata1");
    var dataArr = new Array();
    dataArr[0] = sheet.getSheetValues(2, 6, 1, 1)[0][0];
    dataArr[1] = sheet.getSheetValues(2, 7, 1, 1)[0][0];
    dataArr[2] = sheet.getSheetValues(7, 8, 1, 1)[0][0];
    dataArr[3] = sheet.getSheetValues(7, 9, 1, 1)[0][0];
    dataArr[4] = sheet.getSheetValues(2, 8, 1, 1)[0][0];
    dataArr[5] = sheet.getSheetValues(7, 11, 1, 1)[0][0];
    dataArr[6] = sheet.getSheetValues(2, 12, 1, 1)[0][0];
    dataArr[7] = sheet.getSheetValues(2, 13, 1, 1)[0][0];
    //dataArr[8] = "1";
    var sheet2 = SS.getSheetByName("measureValues");
    var Avals = sheet2.getRange("A2:A").getValues();
    var Alast = Avals.filter(String).length;
    var lastRow = Math.floor(Alast) + 1;
    //sheet2.insertRows(lastRow + 1, 1);
    sheet2.getRange(lastRow + 1, 1, 1, dataArr.length).setValues([dataArr]);
    var sheet3 = SS.getSheetByName("charts");
    dataArr[8] = "1";
    sheet3.getRange(2, 7, 1, dataArr.length).setValues([dataArr]);
    var sheet4 = SS.getSheetByName("sensor");
    var sensorDataArr = new Array();
    var Avals = sheet4.getRange("A2:A").getValues();
    var Alast = Avals.filter(String).length;
    var lastRow = Math.floor(Alast) + 1;
    sensorDataArr[0] = sheet4.getSheetValues(lastRow, 3, 1, 1)[0][0];
    sensorDataArr[1] = sheet4.getSheetValues(lastRow, 4, 1, 1)[0][0];
    sensorDataArr[2] = sheet4.getSheetValues(lastRow, 5, 1, 1)[0][0];
    sheet3.getRange(2, 1, 1, sensorDataArr.length).setValues([sensorDataArr]);
  }
  var range = sheet1.getRange("E2:F2");
  if (!range.isBlank()) {
    var sheet = SS.getSheetByName("tempdata2");
    var dataArr = new Array();
    dataArr[0] = sheet.getSheetValues(2, 6, 1, 1)[0][0];
    dataArr[1] = sheet.getSheetValues(2, 7, 1, 1)[0][0];
    dataArr[2] = sheet.getSheetValues(7, 8, 1, 1)[0][0];
    dataArr[3] = sheet.getSheetValues(7, 9, 1, 1)[0][0];
    dataArr[4] = sheet.getSheetValues(2, 8, 1, 1)[0][0];
    dataArr[5] = sheet.getSheetValues(7, 11, 1, 1)[0][0];
    dataArr[6] = sheet.getSheetValues(2, 12, 1, 1)[0][0];
    dataArr[7] = sheet.getSheetValues(2, 13, 1, 1)[0][0];
    //dataArr[8] = "2";
    var sheet2 = SS.getSheetByName("measureValues");
    var Avals = sheet2.getRange("I2:I").getValues();
    var Alast = Avals.filter(String).length;
    var lastRow = Math.floor(Alast) + 1;
    sheet2.getRange(lastRow + 1, 9, 1, dataArr.length).setValues([dataArr]);
    var sheet3 = SS.getSheetByName("charts");
    dataArr[8] = "2";
    sheet3.getRange(3, 7, 1, dataArr.length).setValues([dataArr]);
    var sheet4 = SS.getSheetByName("sensor");
    var sensorDataArr = new Array();
    var Avals = sheet4.getRange("A2:A").getValues();
    var Alast = Avals.filter(String).length;
    var lastRow = Math.floor(Alast) + 1;
    sensorDataArr[0] = sheet4.getSheetValues(lastRow, 3, 1, 1)[0][0];
    sensorDataArr[1] = sheet4.getSheetValues(lastRow, 4, 1, 1)[0][0];
    sensorDataArr[2] = sheet4.getSheetValues(lastRow, 5, 1, 1)[0][0];
    sheet3.getRange(3, 1, 1, sensorDataArr.length).setValues([sensorDataArr]);
  }
  var range = sheet1.getRange("G2:H2");
  if (!range.isBlank()) {
    var sheet = SS.getSheetByName("tempdata3");
    var dataArr = new Array();
    dataArr[0] = sheet.getSheetValues(2, 6, 1, 1)[0][0];
    dataArr[1] = sheet.getSheetValues(2, 7, 1, 1)[0][0];
    dataArr[2] = sheet.getSheetValues(7, 8, 1, 1)[0][0];
    dataArr[3] = sheet.getSheetValues(7, 9, 1, 1)[0][0];
    dataArr[4] = sheet.getSheetValues(2, 8, 1, 1)[0][0];
    dataArr[5] = sheet.getSheetValues(7, 11, 1, 1)[0][0];
    dataArr[6] = sheet.getSheetValues(2, 12, 1, 1)[0][0];
    dataArr[7] = sheet.getSheetValues(2, 13, 1, 1)[0][0];
    //dataArr[8] = "3";
    var sheet2 = SS.getSheetByName("measureValues");
    var Avals = sheet2.getRange("Q2:Q").getValues();
    var Alast = Avals.filter(String).length;
    var lastRow = Math.floor(Alast) + 1;
    //sheet2.insertRows(lastRow + 1, 1);
    sheet2.getRange(lastRow + 1, 17, 1, dataArr.length).setValues([dataArr]);
    var sheet3 = SS.getSheetByName("charts");
    dataArr[8] = "3";
    sheet3.getRange(4, 7, 1, dataArr.length).setValues([dataArr]);
    var sheet4 = SS.getSheetByName("sensor");
    var sensorDataArr = new Array();
    var Avals = sheet4.getRange("A2:A").getValues();
    var Alast = Avals.filter(String).length;
    var lastRow = Math.floor(Alast) + 1;
    sensorDataArr[0] = sheet4.getSheetValues(lastRow, 3, 1, 1)[0][0];
    sensorDataArr[1] = sheet4.getSheetValues(lastRow, 4, 1, 1)[0][0];
    sensorDataArr[2] = sheet4.getSheetValues(lastRow, 5, 1, 1)[0][0];
    sheet3.getRange(4, 1, 1, sensorDataArr.length).setValues([sensorDataArr]);
  }
  var range = sheet1.getRange("I2:J2");
  if (!range.isBlank()) {
    var sheet = SS.getSheetByName("tempdata4");
    var dataArr = new Array();
    dataArr[0] = sheet.getSheetValues(2, 6, 1, 1)[0][0];
    dataArr[1] = sheet.getSheetValues(2, 7, 1, 1)[0][0];
    dataArr[2] = sheet.getSheetValues(7, 8, 1, 1)[0][0];
    dataArr[3] = sheet.getSheetValues(7, 9, 1, 1)[0][0];
    dataArr[4] = sheet.getSheetValues(2, 8, 1, 1)[0][0];
    dataArr[5] = sheet.getSheetValues(7, 11, 1, 1)[0][0];
    dataArr[6] = sheet.getSheetValues(2, 12, 1, 1)[0][0];
    dataArr[7] = sheet.getSheetValues(2, 13, 1, 1)[0][0];
    //dataArr[8] = "4";
    var sheet2 = SS.getSheetByName("measureValues");
    var Avals = sheet2.getRange("Y2:Y").getValues();
    var Alast = Avals.filter(String).length;
    var lastRow = Math.floor(Alast) + 1;
    //sheet2.insertRows(lastRow + 1, 1);
    sheet2.getRange(lastRow + 1, 25, 1, dataArr.length).setValues([dataArr]);
    var sheet3 = SS.getSheetByName("charts");
    dataArr[8] = "4";
    sheet3.getRange(5, 7, 1, dataArr.length).setValues([dataArr]);
    var sheet4 = SS.getSheetByName("sensor");
    var sensorDataArr = new Array();
    var Avals = sheet4.getRange("A2:A").getValues();
    var Alast = Avals.filter(String).length;
    var lastRow = Math.floor(Alast) + 1;
    sensorDataArr[0] = sheet4.getSheetValues(lastRow, 3, 1, 1)[0][0];
    sensorDataArr[1] = sheet4.getSheetValues(lastRow, 4, 1, 1)[0][0];
    sensorDataArr[2] = sheet4.getSheetValues(lastRow, 5, 1, 1)[0][0];
    sheet3.getRange(5, 1, 1, sensorDataArr.length).setValues([sensorDataArr]);
  }
  var range = sheet1.getRange("K2:L2");
  if (!range.isBlank()) {
    var sheet = SS.getSheetByName("tempdata5");
    var dataArr = new Array();
    dataArr[0] = sheet.getSheetValues(2, 6, 1, 1)[0][0];
    dataArr[1] = sheet.getSheetValues(2, 7, 1, 1)[0][0];
    dataArr[2] = sheet.getSheetValues(7, 8, 1, 1)[0][0];
    dataArr[3] = sheet.getSheetValues(7, 9, 1, 1)[0][0];
    dataArr[4] = sheet.getSheetValues(2, 8, 1, 1)[0][0];
    dataArr[5] = sheet.getSheetValues(7, 11, 1, 1)[0][0];
    dataArr[6] = sheet.getSheetValues(2, 12, 1, 1)[0][0];
    dataArr[7] = sheet.getSheetValues(2, 13, 1, 1)[0][0];
    //dataArr[8] = "5";
    var sheet2 = SS.getSheetByName("measureValues");
    var Avals = sheet2.getRange("AG2:AG").getValues();
    var Alast = Avals.filter(String).length;
    var lastRow = Math.floor(Alast) + 1;
    //sheet2.insertRows(lastRow + 1, 1);
    sheet2.getRange(lastRow + 1, 33, 1, dataArr.length).setValues([dataArr]);
    var sheet3 = SS.getSheetByName("charts");
    dataArr[8] = "5";
    sheet3.getRange(6, 7, 1, dataArr.length).setValues([dataArr]);
    var sheet4 = SS.getSheetByName("sensor");
    var sensorDataArr = new Array();
    var Avals = sheet4.getRange("A2:A").getValues();
    var Alast = Avals.filter(String).length;
    var lastRow = Math.floor(Alast) + 1;
    sensorDataArr[0] = sheet4.getSheetValues(lastRow, 3, 1, 1)[0][0];
    sensorDataArr[1] = sheet4.getSheetValues(lastRow, 4, 1, 1)[0][0];
    sensorDataArr[2] = sheet4.getSheetValues(lastRow, 5, 1, 1)[0][0];
    sheet3.getRange(6, 1, 1, sensorDataArr.length).setValues([sensorDataArr]);
  }
  var range = sheet1.getRange("M2:N2");
  if (!range.isBlank()) {
    var sheet = SS.getSheetByName("tempdata6");
    var dataArr = new Array();
    dataArr[0] = sheet.getSheetValues(2, 6, 1, 1)[0][0];
    dataArr[1] = sheet.getSheetValues(2, 7, 1, 1)[0][0];
    dataArr[2] = sheet.getSheetValues(7, 8, 1, 1)[0][0];
    dataArr[3] = sheet.getSheetValues(7, 9, 1, 1)[0][0];
    dataArr[4] = sheet.getSheetValues(2, 8, 1, 1)[0][0];
    dataArr[5] = sheet.getSheetValues(7, 11, 1, 1)[0][0];
    dataArr[6] = sheet.getSheetValues(2, 12, 1, 1)[0][0];
    dataArr[7] = sheet.getSheetValues(2, 13, 1, 1)[0][0];
    //dataArr[8] = "6";
    var sheet2 = SS.getSheetByName("measureValues");
    var Avals = sheet2.getRange("AO2:AO").getValues();
    var Alast = Avals.filter(String).length;
    var lastRow = Math.floor(Alast) + 1;
    //sheet2.insertRows(lastRow + 1, 1);
    sheet2.getRange(lastRow + 1, 41, 1, dataArr.length).setValues([dataArr]);
    var sheet3 = SS.getSheetByName("charts");
    dataArr[8] = "6";
    sheet3.getRange(7, 7, 1, dataArr.length).setValues([dataArr]);
    var sheet4 = SS.getSheetByName("sensor");
    var sensorDataArr = new Array();
    var Avals = sheet4.getRange("A2:A").getValues();
    var Alast = Avals.filter(String).length;
    var lastRow = Math.floor(Alast) + 1;
    sensorDataArr[0] = sheet4.getSheetValues(lastRow, 3, 1, 1)[0][0];
    sensorDataArr[1] = sheet4.getSheetValues(lastRow, 4, 1, 1)[0][0];
    sensorDataArr[2] = sheet4.getSheetValues(lastRow, 5, 1, 1)[0][0];
    sheet3.getRange(7, 1, 1, sensorDataArr.length).setValues([sensorDataArr]);
  }
  var range = sheet1.getRange("O2:P2");
  if (!range.isBlank()) {
    var sheet = SS.getSheetByName("tempdata7");
    var dataArr = new Array();
    dataArr[0] = sheet.getSheetValues(2, 6, 1, 1)[0][0];
    dataArr[1] = sheet.getSheetValues(2, 7, 1, 1)[0][0];
    dataArr[2] = sheet.getSheetValues(7, 8, 1, 1)[0][0];
    dataArr[3] = sheet.getSheetValues(7, 9, 1, 1)[0][0];
    dataArr[4] = sheet.getSheetValues(2, 8, 1, 1)[0][0];
    dataArr[5] = sheet.getSheetValues(7, 11, 1, 1)[0][0];
    dataArr[6] = sheet.getSheetValues(2, 12, 1, 1)[0][0];
    dataArr[7] = sheet.getSheetValues(2, 13, 1, 1)[0][0];
    //dataArr[8] = "7";
    var sheet2 = SS.getSheetByName("measureValues");
    var Avals = sheet2.getRange("AW2:AW").getValues();
    var Alast = Avals.filter(String).length;
    var lastRow = Math.floor(Alast) + 1;
    //sheet2.insertRows(lastRow + 1, 1);
    sheet2.getRange(lastRow + 1, 49, 1, dataArr.length).setValues([dataArr]);
    var sheet3 = SS.getSheetByName("charts");
    dataArr[8] = "7";
    sheet3.getRange(8, 7, 1, dataArr.length).setValues([dataArr]);
    var sheet4 = SS.getSheetByName("sensor");
    var sensorDataArr = new Array();
    var Avals = sheet4.getRange("A2:A").getValues();
    var Alast = Avals.filter(String).length;
    var lastRow = Math.floor(Alast) + 1;
    sensorDataArr[0] = sheet4.getSheetValues(lastRow, 3, 1, 1)[0][0];
    sensorDataArr[1] = sheet4.getSheetValues(lastRow, 4, 1, 1)[0][0];
    sensorDataArr[2] = sheet4.getSheetValues(lastRow, 5, 1, 1)[0][0];
    sheet3.getRange(8, 1, 1, sensorDataArr.length).setValues([sensorDataArr]);
  }

}